<?php

class comments_default
{
	public function main($vars)
	{
		echo 'Default Class';
	}
}