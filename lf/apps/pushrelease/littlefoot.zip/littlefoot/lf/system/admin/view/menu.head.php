
<?php // Littlefoot CMS - Copyright (c) 2013, Joseph Still. All rights reserved. See license.txt for product license information. /*
[+] <a href="%appurl%create/">create new</a>, <a href="%appurl%view/">view</a>, <a href="%appurl%edit/">edit</a> */ ?>