
<h2><a href="%baseurl%apps/view">App Manager</a> / <?=$var[1];?></h2>
<h3>Manage</h3>
<p>This is a short usage explanation</p>
<?=$manage;?>