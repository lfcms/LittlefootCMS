<?php sleep(1); ?>
<ul class="msglist">
	<li class="user new">
        <div class="msg">
            <a href="">Justin Meller</a> added <a href="">John Doe</a> as Admin.
        </div>
    </li>
    <li class="call new">
        <div class="msg">
            You missed a call from <a href="">Porfirio</a>
        </div>
    </li>
    <li class="calendar new">
        <div class="msg">
            <a href="">Katherine Kate</a> invited you in an event <a href="">Rock Party</a>.
        </div>
    </li>
    <li class="settings">
        <div class="msg">
            <a href="">Jane Doe</a> updated her profile.
        </div>
    </li>
    <li class="user">
        <div class="msg">
            <a href="">Jet Lee</a> is now following you.
        </div>
    </li>
</ul>
<div class="msgmore"><a href="">View All Activities</a></div>