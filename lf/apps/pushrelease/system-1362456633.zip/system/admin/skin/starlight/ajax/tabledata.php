<form action="" method="post" class="stdform quickform">
	<p>This is a sample of quick view/edit of data.</p>
	<div class="one_half">
        <p>
            <label>Rendering Engine</label>
            <input type="text" name="" />
        </p>
            <p>
            <label for="browser">Browser</label>
            <select id="browser" name="browser">
                <option value="">Choose One</option>
                <option value="">Safari</option>
                <option vlaue="">Internet Explorer</option>
                <option value="">Firefox</option>
                <option value="">Google Chrome</option>
            </select>
        </p>
        
        <br />
        
        <p>
        	<button class="submit radius2">Update Changes</button> &nbsp;
            <button class="cancel radius2">Cancel</button>
        </p>
    </div><!--one_half-->
    
    	<div class="one_half last">
            <p>
            <label for="platform">Platform</label>
            <select id="platform" name="platform">
                <option value="">Choose One</option>
                <option value="">Mac OS</option>
                <option vlaue="">Windows</option>
                <option value="">Ubuntu</option>
                <option value="">Mobile</option>
            </select>
            </p>
            
            <p>
            	<label>Engine Version</label>
                <input type="text" name="" class="width100" />
            </p>
        </div><!--one_half last-->

	<br clear="all" />
    
</form>