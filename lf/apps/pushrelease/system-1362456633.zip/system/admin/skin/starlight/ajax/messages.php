<?php sleep(1); ?>
<ul class="msglist">
	<li class="message new">
        <div class="msg">
            From: <a href="">Benjamiin Buttons</a> <span>40m ago</span>
            <a href="" class="subject">Getting Started on Starlight Template</a>
            <p>Vitae dicta sunt explicabo. Nemo enim</p>
        </div>
    </li>
    <li class="message new">
        <div class="msg">
            From: <a href="">ThemePixels Team</a> <span>2 hours ago</span>
            <a href="" class="subject">Thank you for using StarLight Template</a>
            <p>Hi,Eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
        </div>
    </li>
    <li class="message">
        <div class="msg">
            From: <a href="">Katherine Kate</a> <span>40m ago</span>
            <p>Lorem ipsum dolor sit amet...</p>
        </div>
    </li>
    <li class="message">
        <div class="msg">
            From: <a href="">ThemePixels Team</a> <span>Yesterday</span>
            <a href="" class="subject">Events for the next month</a>
            <p>Hi,Eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
        </div>
    </li>
    <li class="message">
        <div class="msg">
            From: <a href="">Katherine Kate</a> <span>2 days ago</span>
            <p>Lorem ipsum dolor sit amet...</p>
        </div>
    </li>
</ul>
<div class="msgmore"><a href="">See All Messages</a></div>