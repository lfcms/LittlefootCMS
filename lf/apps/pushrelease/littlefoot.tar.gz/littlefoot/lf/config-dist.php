<?php

$db['host'] = 'localhost';
$db['user'] = 'mysql_user';
$db['pass'] = 'mysql_passwd';
$db['name'] = 'mysql_database';
$db['prefix'] = 'lf_';

$debug = true;

?>
