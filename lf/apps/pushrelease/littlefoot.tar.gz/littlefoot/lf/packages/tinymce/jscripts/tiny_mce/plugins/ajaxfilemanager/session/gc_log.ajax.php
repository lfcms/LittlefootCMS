<?php die(); ?>
gc start at 16/Dec/2012 22:55:55
