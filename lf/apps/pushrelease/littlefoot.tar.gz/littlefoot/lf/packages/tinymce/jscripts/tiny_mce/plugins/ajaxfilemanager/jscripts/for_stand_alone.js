function cancelSelectFile()
{
    // close popup window
    window.close();
    return false;
}