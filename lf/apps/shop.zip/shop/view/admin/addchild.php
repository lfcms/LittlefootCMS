<form action="%appurl%addcategory" method="post">
	<input type="hidden" name="category" value="<?=$vars[1];?>" />
	<input type="text" name="name" />
	<input type="submit" value="Add Category" />
</form>