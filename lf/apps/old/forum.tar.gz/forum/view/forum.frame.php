<div style="float: left; width: 150px; border-right: 1px solid #333">
    <div class="well sidebar-nav">
		<?=$nav;?>
	</div><!--/.well -->
</div><!--/span-->
<div style="margin-left: 160px; ">
	<?=$app;?>
</div>