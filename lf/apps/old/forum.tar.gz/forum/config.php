<?php

$db['host'] = 'localhost';
$db['user'] = 'bios_like';
$db['pass'] = 'q8uVjw37wmUL247';
$db['name'] = 'bios_estores_likes';
$db['prefix'] = '';

?>