Logged in as: <?php echo $_SESSION['user']; ?> 
<br />
<a href="http://dev.bioshazard.com/projects/apploader/index.php/cms_deploy/session/logout/">Logout?</a>