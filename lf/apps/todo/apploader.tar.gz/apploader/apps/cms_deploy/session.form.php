<form action="http://dev.bioshazard.com/projects/apploader/index.php/cms_deploy/session/" method="post">
	user: <input type="text" name="user" /><br />
	pass: <input type="text" name="pass" /><br />
	<input type="submit" value="Login" />
</form>