<h1>Domains</h1>
<h2>List Domains</h2>
<?php foreach() {?>